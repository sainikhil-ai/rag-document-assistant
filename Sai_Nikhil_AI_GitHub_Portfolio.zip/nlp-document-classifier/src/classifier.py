from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

documents = [
    "Claim approved for vehicle accident repair",
    "Customer requested policy cancellation",
    "Risk score increased due to payment history",
    "Invoice generated for monthly premium",
    "Medical claim submitted for review",
    "Fraud alert triggered for unusual transaction"
]

labels = [
    "claims",
    "policy",
    "risk",
    "billing",
    "claims",
    "fraud"
]

X_train, X_test, y_train, y_test = train_test_split(
    documents, labels, test_size=0.33, random_state=42
)

model = Pipeline([
    ("tfidf", TfidfVectorizer()),
    ("classifier", LogisticRegression(max_iter=1000))
])

model.fit(X_train, y_train)
predictions = model.predict(X_test)

print(classification_report(y_test, predictions, zero_division=0))

sample = ["Customer submitted a claim for hospital visit"]
print("Prediction:", model.predict(sample)[0])
