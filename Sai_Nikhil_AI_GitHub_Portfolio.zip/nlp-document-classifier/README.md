# NLP Document Classifier

A text classification project for categorizing documents using TF-IDF and Logistic Regression.

## Features
- Text preprocessing
- TF-IDF feature extraction
- Document classification model
- Model evaluation

## Tech Stack
Python, scikit-learn, pandas

## How to Run
```bash
pip install -r requirements.txt
python src/classifier.py
```

## Resume Match
This project supports NLP, document classification, HuggingFace-ready workflows, text analytics, and ML model evaluation.
