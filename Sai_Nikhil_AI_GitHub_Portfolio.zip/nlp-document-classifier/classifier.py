
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

docs=["insurance claim","bank transaction","medical claim"]
labels=["insurance","finance","insurance"]

vec=TfidfVectorizer()
X=vec.fit_transform(docs)

model=LogisticRegression()
model.fit(X,labels)

print("Classifier ready")
