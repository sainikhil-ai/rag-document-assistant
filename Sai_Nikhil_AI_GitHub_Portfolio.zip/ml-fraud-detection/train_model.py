
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

data=pd.DataFrame({
    "amount":np.random.rand(1000)*200,
    "attempts":np.random.randint(0,5,1000)
})

data["fraud"]=(data.amount>150).astype(int)

X=data[["amount","attempts"]]
y=data["fraud"]

model=RandomForestClassifier()
model.fit(X,y)

print("Model trained")
