import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score

def generate_data(rows=1000):
    np.random.seed(42)
    data = pd.DataFrame({
        "amount": np.random.exponential(scale=80, size=rows),
        "transaction_hour": np.random.randint(0, 24, size=rows),
        "failed_attempts": np.random.poisson(1, size=rows),
        "account_age_days": np.random.randint(1, 3000, size=rows)
    })
    data["is_fraud"] = (
        (data["amount"] > 200) &
        (data["failed_attempts"] > 2) &
        (data["transaction_hour"].isin([0,1,2,3,4]))
    ).astype(int)
    return data

def train():
    df = generate_data()
    X = df.drop(columns=["is_fraud"])
    y = df["is_fraud"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    print(classification_report(y_test, predictions))
    print("ROC-AUC:", roc_auc_score(y_test, probabilities))

if __name__ == "__main__":
    train()
