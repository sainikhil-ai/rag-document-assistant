# ML Fraud Detection

A machine learning fraud detection project using Python, pandas, scikit-learn, and XGBoost-style modeling.

## Features
- Sample transaction dataset generation
- Data preprocessing
- Train/test split
- Fraud classification model
- Precision, recall, F1-score, ROC-AUC evaluation

## Tech Stack
Python, pandas, NumPy, scikit-learn

## How to Run
```bash
pip install -r requirements.txt
python src/train_model.py
```

## Resume Match
This project supports fraud detection, anomaly detection, model evaluation, feature engineering, and ML model development.
