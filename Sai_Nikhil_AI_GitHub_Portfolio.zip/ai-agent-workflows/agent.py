
class AgentWorkflow:

    def run(self,task):
        if "calculate" in task:
            return self.calc()
        return self.search()

    def calc(self):
        return "Calculator tool executed"

    def search(self):
        return "Search tool executed"
