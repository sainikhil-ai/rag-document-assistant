from fastapi import FastAPI
from pydantic import BaseModel
from app.agent import AgentWorkflow

app = FastAPI(title="AI Agent Workflow System")
agent = AgentWorkflow()

class TaskRequest(BaseModel):
    task: str

@app.get("/")
def home():
    return {"message": "AI Agent Workflow System is running"}

@app.post("/run")
def run_task(request: TaskRequest):
    return agent.run(request.task)
