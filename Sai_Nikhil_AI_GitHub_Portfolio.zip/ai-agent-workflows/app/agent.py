class AgentWorkflow:
    def run(self, task: str):
        route = self.route_task(task)
        if route == "calculator":
            result = self.calculator_tool(task)
        elif route == "summary":
            result = self.summarizer_tool(task)
        else:
            result = self.search_tool(task)

        return {
            "task": task,
            "selected_tool": route,
            "result": result,
            "workflow_steps": [
                "Received user task",
                "Classified intent",
                f"Selected {route} tool",
                "Returned final response"
            ]
        }

    def route_task(self, task: str):
        lower_task = task.lower()
        if any(word in lower_task for word in ["calculate", "sum", "add"]):
            return "calculator"
        if any(word in lower_task for word in ["summarize", "summary"]):
            return "summary"
        return "search"

    def calculator_tool(self, task: str):
        return "Calculator tool selected. Add safe parsing for production use."

    def summarizer_tool(self, task: str):
        return "Summary: This task requests a condensed explanation of the provided content."

    def search_tool(self, task: str):
        return "Search tool selected. In production, connect this to a vector database or search API."
