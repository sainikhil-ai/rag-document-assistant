# AI Agent Workflow System

A simple AI agent workflow system that demonstrates task routing, tool selection, and multi-step reasoning flow.

## Features
- Rule-based agent router
- Calculator tool
- Search simulation tool
- Document summarization tool
- Workflow execution logs

## Tech Stack
Python, FastAPI, Pydantic

## How to Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Resume Match
This project supports AI agents, tool calling, workflow automation, LangGraph-style architecture, and agent orchestration.
