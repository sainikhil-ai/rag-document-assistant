from fastapi import FastAPI
from pydantic import BaseModel
from app.chatbot import ChatbotService

app = FastAPI(title="LLM Chatbot API")
chatbot = ChatbotService()

class ChatRequest(BaseModel):
    session_id: str
    message: str

@app.get("/")
def home():
    return {"message": "LLM Chatbot API is running"}

@app.post("/chat")
def chat(request: ChatRequest):
    return chatbot.respond(request.session_id, request.message)
