class ChatbotService:
    def __init__(self):
        self.memory = {}

    def respond(self, session_id: str, message: str):
        history = self.memory.get(session_id, [])
        prompt = self.build_prompt(history, message)

        response = (
            "This is a demo chatbot response. In production, connect this prompt "
            "to OpenAI, Azure OpenAI, Claude, or another LLM provider."
        )

        history.append({"user": message, "assistant": response})
        self.memory[session_id] = history[-5:]

        return {
            "session_id": session_id,
            "prompt": prompt,
            "response": response,
            "history_length": len(self.memory[session_id])
        }

    def build_prompt(self, history, message):
        previous_context = "\n".join(
            [f"User: {item['user']}\nAssistant: {item['assistant']}" for item in history]
        )
        return f"""You are a helpful AI assistant.
Conversation history:
{previous_context}

User message:
{message}

Assistant response:
"""
