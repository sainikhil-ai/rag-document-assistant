# LLM Chatbot API

A simple chatbot API structure that demonstrates prompt engineering, conversational memory, and REST API deployment.

## Features
- FastAPI chatbot endpoint
- Prompt template
- Session-based memory simulation
- LLM-ready architecture

## Tech Stack
Python, FastAPI, Pydantic

## How to Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Resume Match
This project supports LLM applications, chatbot API development, prompt engineering, FastAPI, and production AI service design.
