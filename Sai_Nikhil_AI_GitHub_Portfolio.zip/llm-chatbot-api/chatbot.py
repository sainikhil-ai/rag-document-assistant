
class Chatbot:

    def reply(self,msg):
        return "Demo LLM response for: "+msg
