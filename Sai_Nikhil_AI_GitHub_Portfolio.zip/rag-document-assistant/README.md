# RAG Document Assistant

A lightweight Retrieval-Augmented Generation (RAG) document assistant using Python, FastAPI, FAISS-style vector search, and LLM-ready prompt construction.

## Features
- Upload and process text documents
- Chunk documents into searchable passages
- Generate embeddings using TF-IDF demo vectorizer
- Retrieve relevant context for a user question
- Return grounded answers using retrieved context
- FastAPI endpoint for search and Q&A

## Tech Stack
Python, FastAPI, scikit-learn, NumPy, Pydantic

## How to Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## API
```bash
POST /ask
{
  "question": "What is this document about?"
}
```

## Resume Match
This project supports resume keywords such as RAG, semantic search, document intelligence, FastAPI, embeddings, and vector retrieval.
